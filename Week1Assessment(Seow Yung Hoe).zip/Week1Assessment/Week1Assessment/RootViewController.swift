//
//  ViewController.swift
//  Week1Assessment
//
//  Created by Seow Yung Hoe on 13/01/2017.
//  Copyright © 2017 Seow Yung Hoe. All rights reserved.
//

import UIKit

class RootViewController: UIViewController {
    
    

    
    //Outlets
    
    @IBOutlet weak var textField1: UITextField!
    
    @IBOutlet weak var textField2: UITextField!
    
    @IBOutlet weak var button: UIButton!
    //Actions
    
    @IBAction func pressedButton(_ sender: UIButton) {
        
        
        
        guard let text1 = textField1.text ,
            let text2 = textField2.text else { return }
        
        //        //if textField1.text != nil {
        //            let text = textField1.text!
        //        } else {
        //            return
        //        }
        //   if r
        
        
        var userInput = Int(text1) ?? 0
        var userInput2 = Int(text2) ?? 0
        let rightAnswer = 999
        
        
        if userInput + userInput2 == rightAnswer{
            button.isEnabled = true
            afterRightAnswerAlert(message: "What you looking at?")
        }else {

        }
        
        
        
    }
    
    //ETC FUNC
    func afterRightAnswerAlert(message: String){
        
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        
        let thanks = UIAlertAction(title: "Thanks", style: .default, handler: nil)
        
        alert.addAction(thanks)
    }
    
    
//View Did Load
    override func viewDidLoad() {
        super.viewDidLoad()
        
        button.isEnabled = false
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    



}

