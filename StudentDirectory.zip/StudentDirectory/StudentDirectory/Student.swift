//
//  Student.swift
//  StudentDirectory
//
//  Created by Seow Yung Hoe on 25/01/2017.
//  Copyright © 2017 Seow Yung Hoe. All rights reserved.
//

import UIKit
import CoreData

class Student: NSManagedObject {

    @NSManaged var age : Int16
    @NSManaged var name : String?
    @NSManaged var address : String?
    
}
