//
//  ViewController.swift
//  StudentDirectory
//
//  Created by Seow Yung Hoe on 25/01/2017.
//  Copyright © 2017 Seow Yung Hoe. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var tableView: UITableView! {
        didSet {
            tableView.dataSource = self
        }
    }
    
    @IBOutlet weak var saveButton: UIButton! {
        didSet {
            saveButton.setTitle("SAVE", for: .normal)
            saveButton.addTarget(self, action: #selector(saveStudentName), for: .touchUpInside)
        }
    }
    var allStudent : [Student] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        fetchAllStudent()

}


    func saveStudentName() {
        
        guard let validName = textField.text else {
            return}

        //Create Entity
        let studentEntity = NSEntityDescription.entity(forEntityName: "Student", in: CoreDataController.shared.managedObjectContext)
        // create the object nd insert into context
        let newStudent = Student(entity: studentEntity!, insertInto: CoreDataController.shared.managedObjectContext)
    
    newStudent.name = validName
        
//        newStudent.age = 24
//        newStudent.name = "Rock Lee"
//        newStudent.address = "Konoha Village"
        
        
        do {
            try CoreDataController.shared.managedObjectContext.save()
            fetchAllStudent()
        } catch let error {
            debugPrint(error)
        }
    
 
    }
    
    func fetchAllStudent() {
        
        let context = CoreDataController.shared.managedObjectContext
        
        let fetchRequest = NSFetchRequest<Student>(entityName: "Student")
        
        do {
            let fetchedStudents = try context.fetch(fetchRequest)
            
//            for student in fetchedStudents {
//                print("Student is : \(student.name) age:\(student.age),address:\(student.address)")
            allStudent = fetchedStudents
            tableView.reloadData()
        }catch let error {
            debugPrint(error)
        }
    
    

}
    
}

extension ViewController : UITableViewDataSource {
    
    func tableView(_ tableVIew: UITableView, numberOfRowsInSection section:Int) -> Int {
    
        return allStudent.count

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath:IndexPath) -> UITableViewCell {
    
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let student = allStudent[indexPath.row]
        cell.textLabel?.text = student.name
        return cell
 
    }

}



