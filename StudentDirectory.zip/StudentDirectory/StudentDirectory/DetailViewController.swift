//
//  DetailViewController.swift
//  StudentDirectory
//
//  Created by Seow Yung Hoe on 25/01/2017.
//  Copyright © 2017 Seow Yung Hoe. All rights reserved.
//

import UIKit
import CoreData

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        fetchData()
    }


    func fetchData() {
        
        let context = CoreDataController.shared.managedObjectContext
        
        let fetchRequest = NSFetchRequest<Student>(entityName: "Student")
        
        do {
            let fetchedStudents = try context.fetch(fetchRequest)
            
            for student in fetchedStudents {
                print("Student is : \(student.name) age:\(student.age),address:\(student.address)")
            }
        }catch let error {
            debugPrint(error)
        }
        
    }
    
}
