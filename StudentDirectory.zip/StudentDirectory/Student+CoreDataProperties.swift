//
//  Entity+CoreDataProperties.swift
//  StudentDirectory
//
//  Created by Seow Yung Hoe on 25/01/2017.
//  Copyright © 2017 Seow Yung Hoe. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData


extension Student {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Student> {
        return NSFetchRequest<Student>(entityName: "Student");
    }


}
