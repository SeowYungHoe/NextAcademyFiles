//
//  Student+CoreDataClass.swift
//  StudentDirectory
//
//  Created by Seow Yung Hoe on 25/01/2017.
//  Copyright © 2017 Seow Yung Hoe. All rights reserved.
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
