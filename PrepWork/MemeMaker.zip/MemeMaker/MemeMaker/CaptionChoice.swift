//
//  CaptionChoice.swift
//  MemeMaker
//
//  Created by Seow Yung Hoe on 06/01/2017.
//  Copyright © 2017 Seow Yung Hoe. All rights reserved.
//

import Foundation

struct CaptionOption {
    let caption: String
    let emoji: String
}
